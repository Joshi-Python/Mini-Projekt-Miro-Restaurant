def miro_restaurant():
    # Pizzen Liste
    pizza_liste = []

    # Auflauf Liste
    auflauf_liste = []

    # Pizzen Unterlisten
    pizza_list_number = ['100. ', '101.', '102. ']
    pizza_list_name   = ['Pizza Margeritta ', ' Pizza Thunfisch ', 'Pizza Fungi ']
    pizza_list_price  = ['5€', '6€', '7€']

    # Auflauf Unterlisten
    auflauf_list_number = ['200.', '201.']
    auflauf_list_name   = [' Auflauf Nudel', ' Auflauf Kartoffeln']
    auflauf_list_price  = [' 8€', ' 9€']

    # Pizzen entpacken in Oberliste
    pizza_mageritta = pizza_list_number[0] + pizza_list_name[0] + pizza_list_price[0]
    pizza_thunfisch = pizza_list_number[1] + pizza_list_name[1] + pizza_list_price[1]
    pizza_fungi     = pizza_list_number[2] + pizza_list_name[2] + pizza_list_price[2]

    # Pizza Variablen in Liste packen
    pizza_liste = [pizza_mageritta, pizza_thunfisch, pizza_fungi]

    # Pizzen in Variable packen
    pizzen = f'{pizza_liste[0]}\n{pizza_liste[1]}\n{pizza_liste[2]}'

    # Aufläufe in Oberliste packen
    auflauf_nudel       = auflauf_list_number[0] + auflauf_list_name[0] + auflauf_list_price[0]
    auflauf_kartoffeln  = auflauf_list_number[1] + auflauf_list_name[1] + auflauf_list_price[1]

    # Auflauf Variablen in Liste packen
    auflauf_liste = [auflauf_nudel, auflauf_kartoffeln]

    # Auflauf Liste in Variable packen
    auflauf = f'{auflauf_liste[0]}\n{auflauf_liste[1]}'

    # Programm-Start: Menü ausgeben
    print('Willkommen bei Miro Restaurant')
    print('-'*35)
    print('Pizzen')
    print(pizzen)
    print('-' * 35)
    print()
    print('Auflauf')
    print('-' * 35)
    print(auflauf)
    print('-'*35)
    print()
    print('='*35)
    print('Was möchten Sie bestellen?')
    print('=' * 35)


    # Bestell-Listen
    bestell_number = []
    bestell_name   = []
    bestell_price  = []

    # Bestell-Schleife
    while True:
        order = input('>> ').strip()
        if order == (''):
            break

        gefunden = False

        # Suche in Pizza-Listen
        for i in range(len(pizza_list_number)):
            nummer = pizza_list_number[i].strip().replace('.', '')
            if order == nummer:
                bestell_number.append(nummer)
                bestell_name.append(pizza_list_name[i].strip())
                bestell_price.append(int(pizza_list_price[i].replace('€', '')))
                gefunden = True
                break

        # Suche in Auflauf-Listen
        if not gefunden:
            for i in range(len(auflauf_list_number)):
                nummer = auflauf_list_number[i].strip().replace('.', '')
                if order == nummer:
                    bestell_number.append(nummer)
                    bestell_name.append(auflauf_list_name[i].strip())
                    bestell_price.append(int(auflauf_list_price[i].replace('€', '')))
                    gefunden = True
                    break

        if not gefunden:
            print('Leider bieten wir das nicht an')

    # Quittung
    print('\nQuittung')
    print('=' * 8)
    gesamt = 0
    for i in range(len(bestell_number)):
        print(f'{bestell_number[i]}. {bestell_name[i]} {bestell_price[i]}€')
        gesamt += bestell_price[i]
    print(f'Die Summe beträgt: {gesamt}€')
    print('Vielen Dank für Ihren Besuch!')

if __name__ == '__main__':
    miro_restaurant()


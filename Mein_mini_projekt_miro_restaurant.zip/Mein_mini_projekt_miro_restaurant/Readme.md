# Mein Mini-Projekt: Miro Restaurant

# Technologien
- Python 3

# Was ich gelernt habe
- Das Erstellen von while- und for-Schleifen

  - Das Erstellen von Unterlisten, die ich in einer Liste speichere
    und anschließend in eine Variable entpacke

# Beschreibung
Das ist ein kleines Mini-Projekt von mir mit den Grundlagen von Python.
Wenn man das Programm startet, werden die Gerichte mit den entsprechenden
Preisen und Bestellnummern ausgegeben.

Der Benutzer gibt dann – wie in einem normalen Restaurant – seine Bestellung mit der dazugehörigen Nummer ein.
Wenn man das Programm beenden möchte, drückt man die Enter-Taste (Eingabetaste).

Am Ende erhält man eine Quittung mit den bestellten Gerichten.

Installation
- Python 3
- Visual Studio Code
- PyCharm Community Edition

# Starten
python main.py

